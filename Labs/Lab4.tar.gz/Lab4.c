/*
   LAB#4

   FILL IN AND TEST ALL THESE FUNCTIONS PROTOTYPED BELOW
   SEVERAL ARE ALREADY FILED IN such as insertAtFront() and printList(), fatal, etc.

RUBRIK:

worth 15% searchNode
worth 20% insertAtTail  - MUST RE_USE insertAtFront
worth 10% removeAtFront
worth 40% removeNode    - MUST RE_USE removeAtFront
worth 15% freeList      - MUST RE_USE removeAtFront

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct Node
{
  char  *word;
  struct Node  *next;
} Node;


Node *searchNode( Node * head, char * key );
void insertAtFront( Node **head, char * key );  // ALREADY WRITTEN FOR YOU
void insertAtTail( Node **head, char * key );
void removeAtFront( Node ** head );
void removeNode( Node **head, char * key );
void freeList( Node **head );
void printList( Node * head ); // ALREADY WRITTEN FOR YOU
void fatal( char * msg ); // ALREADY WRITTEN FOR YOU

#define BUFFER_CAP 20

int main()
{
  Node *head = NULL;

  while (1)
  {
		char option;
		printf("\nChoose 'H'ead Insert, 'T'ail insert, 'R'emove, 'S'earch, F'ree, 'Q'uit " );
		fflush( stdout );
		int result = scanf(" %c%*[^\n]", &option); getchar();  // MAGIC BULLET TO CORRECTLY READ A SINGLE CHAR FROM STDIN
		if (result <1) fatal("failure reading from stdin\n");

		if (option == 'H' )
		{
			char * word=malloc(BUFFER_CAP);  // DONT ENTER ANY LONG WORDS!
			printf("Enter a word to insertAtFront: " );
			fflush( stdout );
			char * result = fgets( word, BUFFER_CAP, stdin );
			if (result==NULL) fatal("failure reading from stdin\n");
			strtok(word,"\n"); // overwrites '\n' with  '\0'
			insertAtFront( &head, word ); /* shallow copy string into list   */
			printList( head );
		}
		if (option == 'T' )
		{
			char * word=malloc(BUFFER_CAP);  // DONT ENTER ANY LONG WORDS!
			printf("Enter a word to insertAtTail: " );
			fflush( stdout );
			char * result = fgets( word, BUFFER_CAP, stdin );
			if (result==NULL) fatal("failure reading from stdin\n");
			strtok(word,"\n"); // overwrites '\n' with  '\0'
			insertAtTail( &head, word ); /* shallow copy string into list   */
			printList( head );
		}
    		if (option == 'R' )
		{
			char * word=malloc(BUFFER_CAP);  // DONT ENTER ANY LONG WORDS!
			printf("Enter a word to remove: " );
			fflush( stdout );
			char * result = fgets( word, BUFFER_CAP, stdin );
			if (result==NULL) fatal("failure reading from stdin\n");
			strtok(word,"\n"); // overwrites '\n' with  '\0'
			removeNode( &head, word );
			printList( head );
			free( word ); // we were just using it for matching
		}
		if (option == 'S' )
		{
			char * word=malloc(BUFFER_CAP);  // DONT ENTER ANY LONG WORDS!
			printf("Enter a word to find: " );
			fflush( stdout );
			char * result = fgets( word, BUFFER_CAP, stdin );
			if (result==NULL) fatal("failure reading from stdin\n");
			strtok(word,"\n"); // overwrites '\n' with  '\0'
			if (searchNode( head, word ))
				fprintf(stderr, "%s FOUND\n",word );
			else
				fprintf(stderr, "%s NOT FOUND\n",word );
			printList( head );
			free( word ); // we were just using it for matching
		}
		if (option == 'F' ) // free the entire list (remember to set head to NULL)
		{
			freeList( &head );
			printList( head );
		}
		else if (option == 'Q' )
			exit( 0 );
	} // END WHILE

  	return 0;
}

//  # # # # # # # # # # # # # # # # # # # # # # #
//  # # # # # # # # # # # # # # # # # # # # # # #

// GIVEN AS IS - DO NOT MODIFY
void printList( Node * head )
{
	fprintf(stderr, "\nLIST: ");
	while (head)
	{
		fprintf(stderr, "%s ", head->word );
		head=head->next;
	}
	int result =  fprintf(stderr, "\n");
	if (result<1) fatal("failure writing to stdout\n");
}


// GIVEN AS IS - DO NOT MODIFY
void fatal( char * msg )
{
	printf("\nFatal Error: %s\n\n", msg );
	exit(0);
}

// GIVEN AS IS - DO NOT MODIFY
void insertAtFront( Node **head, char * key )
{
	Node *new =  malloc( sizeof(Node) );
	if (!new)  fatal("Malloc of new Node failed");
	new->word = key;
	new->next = *head;
	*head = new;
}

void insertAtTail( Node **head, char * word )
{
	Node *curr = malloc( sizeof(Node) );
	curr = *head;
	if (curr == NULL){
		insertAtFront(head, word);
		return;
	}
	while (curr->next != NULL){
		curr = curr->next;
	}
	Node *new = malloc(sizeof(Node));
	new->word = word;
	curr->next = new;
}

void removeAtFront( Node ** head )
{
	free(*head);
	//YOUR CODE HERE
}

void removeNode( Node ** head, char * key )
{
	Node *curr = malloc(sizeof(Node));
	curr = *head;

	if(curr != NULL && strncmp(curr->word, key, sizeof(key)) == 0){
		curr = curr->next;
		removeAtFront(head);
		*head = curr;
		return;
	}
	while(curr->next != NULL && strncmp(curr->next->word, key, sizeof(key)) != 0){
		curr = curr->next;
	}
	if(curr != NULL){
		Node *newNext = malloc(sizeof(Node));
		newNext = curr->next->next;
		removeAtFront(curr->next);
		curr->next = newNext;
	}
	//YOUR CODE HERE
}

Node * searchNode ( Node * head, char * key )
{
	Node *curr = malloc( sizeof(Node) );
	curr = head;
	while (curr != NULL && strncmp(curr->word, key, sizeof(key)) != 0){
		curr = curr->next;
	}
	return curr;
	//YOUR CODE HERE
}

void freeList(  Node ** head )
{
	Node *curr = malloc(sizeof(Node));
	curr = *head;
	while(curr != NULL){
		curr = curr->next;
		removeAtFront(head);
		*head = curr;
	}
}
